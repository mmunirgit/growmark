#!/usr/bin/python
import csv
import sys
import time


# utils
def log(*args, **kwargs):
    """
    Using log to replace print for better debugging.
    By default, all logs will be saved in calendar.log.txt
    """
    pass
    # if 'path' not in kwargs:
    #     log_path = './log/gma.log.txt'
    # else:
    #     log_path = kwargs['path']
    #     kwargs.pop('path')
    #
    # t_format = '%H:%M:%S'
    # value = time.localtime(int(time.time()))
    # dt = time.strftime(t_format, value)
    # with open(log_path, 'a', encoding='utf-8') as f:
    #     print(dt, *args, file=f, **kwargs)


def append_2_list_in_dict(my_dict, my_key, new_entry):
    """
    If dict contains key, append the entry to list, otherwise create the list as value of the dict_key and append entry.
    :param my_dict: dict you want to manipulate
    :param my_key: key of my_dict
    :param new_entry: entry you want to append to my_dict[my_key]
    :return: void
    """
    if my_key not in my_dict:
        my_dict[my_key] = []
    else:
        pass
    my_dict[my_key].append(new_entry)


def add_2_set_in_dict(my_dict, my_key, new_element):
    """
    If dict contains key, add the element to set, otherwise create the set as value of the dict_key and add the element.
    :param my_dict: dict you want to manipulate
    :param my_key: key of my_dict
    :param new_element: element you want to append to my_dict[my_key]
    :return: void
    """
    if my_key not in my_dict:
        my_dict[my_key] = set([])
    else:
        pass
    my_dict[my_key].add(new_element)


def get_doctype_id(doc_id, docid_prefix_factor):
    """
    Get doctype_id for given docid.
    :param doc_id: document id
    :param docid_prefix_factor: doctype * docid_prefix_factor + row_number is docid in connector
    :return: doctype
    """
    return int(int(doc_id)/int(docid_prefix_factor))


def fix_e_in_csv(csv):
    """
    Fix e problem in given csv file and save as 'filename_efixed.csv' in the same directory
    :param csv: csv file with "e" bug
    :return: fixed csv file
    """
    output_path = csv.split('.csv')[0] + '_efixed.csv'
    line_number = 0
    with open(csv, "rt") as fin:
        with open(output_path, "wt") as fout:
            for line in fin:
                line_number += 1
                if 'e+' in line:
                    print('line {}: find e+ in'.format(line_number))
                    values = line.split(";")
                    for i in range(len(values)):
                        if 'e+' in values[i]:
                            a, b = values[i].split('e+')
                            values[i] = str(int(float(a) * (10 ** int(b))))
                    fixed_line = ';'.join(values)
                    fout.write(fixed_line)
                else:
                    fout.write(line)


# Model: Directed graph
class Digraph:
    t_dict = {}     # t_dict[doctype_id] = all vertex_ids which falls under the doc type
    adj_to = {}     # adjacency dict, adj_to[v] stores vertices pointing to v
    adj_from = {}   # adjacency dict, adj_from[v] stores vertices pointing from v
    visited_vertices_forward = set()
    visited_vertices_backward = set()
    visited_source = set()

    def __init__(self):
        pass

    def add_edge(self, docid_v, docid_w, doctype_v, doctype_w):
        """
        int v -> int w
        Add vertex v to adj_to[w],
        Add vertex w to adj_from[v].
        :param docid_v: head of edge
        :param docid_w: tail of edge
        :param doctype_v: doctype_id of vertex v
        :param doctype_w: doctype_id of vertex w
        :return: void
        """
        # add docid to t_dict
        add_2_set_in_dict(self.t_dict, doctype_v, docid_v)
        add_2_set_in_dict(self.t_dict, doctype_w, docid_w)

        # add edge to adjacency dict
        append_2_list_in_dict(self.adj_to, docid_w, docid_v)
        append_2_list_in_dict(self.adj_from, docid_v, docid_w)

    def get_trace_dfs(self, docid, direction, trace=None):
        """
        Get trace for a source vertex docid by using depth first search implemented with recursively call itself.
        :param docid: docid of source vertex for the first time called, then docid of vertex in the trace
        :param direction: direction of dfs, either 'forward' or 'backward'
        :param trace: store the trace for throughout a dfs
        :return: trace of case which contain all vertices(events) that fall under the cases
        """
        # Initiate the trace and marked
        if trace is None:
            trace = []
        # log('{}: Now visit vertex {}'.format(direction, docid))
        # log('current trace is {}'.format(trace))
        if direction == 'forward':
            if docid not in self.visited_vertices_forward:
                self.visited_vertices_forward.add(docid)
                self.visited_source.add(docid)
                trace.append(docid)
                if docid in self.adj_from:   # check whether exist vertices which are pointed from current vertex
                    for v in self.adj_from[docid]:
                        self.get_trace_dfs(v, 'forward', trace)

        elif direction == 'backward':
            if docid not in self.visited_vertices_backward:
                self.visited_vertices_backward.add(docid)
                self.visited_source.add(docid)
                trace.append(docid)
                if docid in self.adj_to:   # check whether exist vertices which are pointed to current vertex
                    for v in self.adj_to[docid]:
                        self.get_trace_dfs(v, 'backward', trace)

        return trace

    def graph2json(self):
        """
        Serialization of the graph.
        :return: json of the graph
        """
        pass


# GMA
def create_digraph(mapping_table, docid_prefix):
    """
    Load mapping table
    :param mapping_table: file address of mapping_table
    :return: created digraph
    """
    log('Start creating digraph...')

    digraph = Digraph()
    with open(mapping_table) as f:
        reader = csv.DictReader(f, delimiter=';')
        #fieldnames = next(reader)

        # Load mapping(edge) and create Digraph
        for row in reader:
            docid_a = row['DocID_A']
            docid_b = row['DocID_B']
            doctype_a = get_doctype_id(docid_a, docid_prefix)
            doctype_b = get_doctype_id(docid_b, docid_prefix)
            digraph.add_edge(docid_a, docid_b, doctype_a, doctype_b)

    log('Digraph created.\n')
    return digraph


def load_doctype(doctype_table):
    """
    Load the doctype_list from doctype_table
    :param doctype_table: file address of doctype_table
    :return: doctype_list which stores all available doctype_list for future checking in load_priority
    """
    doctype_list = []
    with open(doctype_table, 'r') as f:

        # Check header
        right_header = "Table;Field;Field value;Subfield;Subfield value;DocType;Description"
        header = f.readline().rstrip()
        if header != right_header:
            raise Exception("doctype_table header should be '{}', ".format(header) +
                            "but '{}' encountered. ".format(header))

        # Load all available doctype_id
        for line in f:
            _, _, _, _, _, doctype_id, _ = line.rstrip().split(";")
            doctype_list.append(doctype_id)
        return doctype_list


def load_priority(priority_table, doctype_list):
    """
    Parse the priority_table to priority list
    :param doctype_list: which stores all available doctype_id
    :param priority_table: file address of priority_table
    :return: priority list, e.g [1, 3]
    """
    with open(priority_table, 'r') as f:
        priority_list = f.readline().rstrip().split(";")
        for p in priority_list:
            if p not in doctype_list:
                raise Exception("priority_table contains unexpected value '{}', ".format(p) +
                                "which is not in doctype_table")
    return priority_list


def create_case_dict(digraph, priority_list):
    """
    Create case dict for given digraph and priority list
    :param digraph: digraph which should be a Digraph object
    :param priority_list: list of doctype priority, e.g [1, 3]
    :return: case dict, e.g {1001: [1001, 2001, 3001], 2002: [1002, 2002]}
    """
    log('Start creating case dict (DFS)...')

    case_dict = {}
    for p in priority_list:
        for source in digraph.t_dict[int(p)]:
            if source in digraph.visited_source:
                pass
            else:
                # DFS a source then clear the visited_vertices forward and backward
                trace_forward = digraph.get_trace_dfs(source, 'forward')
                digraph.visited_vertices_forward = set()
                trace_backward = digraph.get_trace_dfs(source, 'backward')
                digraph.visited_vertices_backward = set()
                case_dict[source] = set(trace_backward + trace_forward)
    log('Case_dict (DFS) created.\n')
    return case_dict


def generate_case_table(case_dict, filename):
    """
    Write case dict to csv file
    :param case_dict: case dict which should returned by create_case_dict()
    :param filename: csv file address
    :return: void
    """
    log('Start generating case table...')

    header = "caseID;caseTypeID;docID;docTypeID"
    with open(filename, 'w') as f:
        print(header, file=f)
        for key in case_dict:
            for docid in case_dict[key]:
                print("{};{};{};{}".format(key, get_doctype_id(key), docid, get_doctype_id(docid)), file=f)

    log('Case table generated.\n')


def stdout_case_table(case_dict, docid_prefix):
    """
    Write case dict to stdout
    :param case_dict: case dict which should returned by create_case_dict()
    :return: void
    """
    log('Start stdout case table...')

    fieldnames = ['caseID', 'caseTypeID', 'docID', 'docTypeID']

    writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames, delimiter=';', restval='', quoting=csv.QUOTE_ALL)
    writer.writeheader()
    for key in case_dict:
        for docid in case_dict[key]:
            writer.writerow({'caseID': key, 'caseTypeID': get_doctype_id(key, docid_prefix),
                             'docID': docid, 'docTypeID': get_doctype_id(docid, docid_prefix)})

    log('Case table stdout.\n')


def graph_mining_algo(mapping_table, priority_str, docid_prefix, case_table=None, old_case_table=None,
                      check_output=False, check_mapping=False):
    """
    The runner.
    Notice that the log generated are stored in ./log/
    :param mapping_table: file address of mapping table (input)
    :param priority_str: a string of priority(input)
    :param case_table: file address of case table (output)
    :param old_case_table: file address of old case table (input) for further comparison
    :param check_output: If True, will compare and get stats of the generated case_table with the old_case_table
    :param check_mapping: If True, will get stats of mapping table
    :return: void
    """

    log("*" * 8 + "GMA Started" + "*" * 8)

    # Path and file setting
    if check_mapping:
        pass
        # log('Start checking input mapping table...')
        # csv_stats.analyze_mapping_table(mapping_table)
        # log('Input mapping table checking done, please refer to log/mapping_table_checker.log.txt for more details.\n')

    # Create Graph
    my_digraph = create_digraph(mapping_table, docid_prefix)

    # Generate case table
    priority_list = priority_str.split(',')
    my_case_dict = create_case_dict(my_digraph, priority_list)

    if case_table is None:
        stdout_case_table(my_case_dict, docid_prefix)
    else:
        generate_case_table(my_case_dict, case_table)

    if check_output and old_case_table is not None:
        pass
        # log('Start checking output...')
        # csv_stats.compare_case_tables(case_table, old_case_table, 'py', 'cs')
        # log('Output checking done, please refer to log/case_table_compare.log.tx for more details.\n')

    log("*" * 8 + "GMA Ended" + "*" * 8 + '\n\n')


def main():
    mapping_table = sys.argv[1]
    priority_str = sys.argv[2]
    docid_prefix = sys.argv[3]
    #mapping_table = "/Users/qiangsuo/Downloads/Text.csv"
    #priority_str = '166'
    #docid_prefix = 10000000000
    graph_mining_algo(mapping_table, priority_str, docid_prefix)


if __name__ == '__main__':
    main()
